
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
// Carrega variáveis do .env sem depender de ferramenta externa.
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && !Object.prototype.hasOwnProperty.call(process.env, match[1])) {
      process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
    }
  }
}

const express = require('express');
const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const ROOT = __dirname;
const bla = ROOT;
const SECRET_DIR = path.join(ROOT, 'lib', 'secret');
const KEYS_FILE = path.join(SECRET_DIR, 'keys.json');
const USERS_FILE = path.join(SECRET_DIR, 'usuarios.json');
const METRICS_FILE = path.join(SECRET_DIR, 'metrics.json');

app.set('trust proxy', 1);
app.use(express.json({ limit: '32kb' }));
app.use(express.urlencoded({ extended: false, limit: '32kb' }));
app.use(express.static(path.join(ROOT, 'public')));

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(value, null, 2));
  fs.renameSync(temp, file);
}

let key = readJson(KEYS_FILE, []);
if (!Array.isArray(key)) key = [];
let users = readJson(USERS_FILE, []);
if (!Array.isArray(users)) users = [];
let metrics = readJson(METRICS_FILE, { totalRequests: 0, startedAt: new Date().toISOString() });
if (!metrics || typeof metrics !== 'object') metrics = { totalRequests: 0, startedAt: new Date().toISOString() };
if (!Number.isFinite(Number(metrics.totalRequests))) metrics.totalRequests = 0;

const sessions = new Map();
const loginAttempts = new Map();
const SESSION_TTL = 8 * 60 * 60 * 1000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const OWNER_WHATSAPP = String(process.env.OWNER_WHATSAPP || '').replace(/\D/g, '');
const OWNER_INSTAGRAM = String(process.env.OWNER_INSTAGRAM || '').replace(/^@/, '').trim();

console.log('[SIXVOID] ADMIN_PASSWORD carregada:', Boolean(ADMIN_PASSWORD));
console.log('[SIXVOID] Tamanho da senha:', ADMIN_PASSWORD.length);

function parseCookies(req) {
  const raw = req.headers.cookie || '';
  return Object.fromEntries(raw.split(';').map(v => v.trim()).filter(Boolean).map(v => {
    const i = v.indexOf('=');
    return i < 0 ? [v, ''] : [v.slice(0, i), decodeURIComponent(v.slice(i + 1))];
  }));
}
function isAdmin(req) {
  const token = parseCookies(req).sixvoid_admin;
  if (!token) return false;
  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    sessions.delete(token);
    return false;
  }
  session.expiresAt = Date.now() + SESSION_TTL;
  return true;
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(401).json({ success: false, message: 'Sessão administrativa expirada.' });
  next();
}
function sameSecret(a, b) {
  const aa = Buffer.from(String(a || ''));
  const bb = Buffer.from(String(b || ''));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function saveKeys() { writeJson(KEYS_FILE, key); }
function saveUsers() { writeJson(USERS_FILE, users); }
function saveMetrics() { writeJson(METRICS_FILE, metrics); }

// Bloqueia imediatamente qualquer chamada feita com uma credencial suspensa.
app.use((req, res, next) => {
  const apikey = req.query?.apikey;
  if (!apikey || req.path.startsWith('/api/admin/')) return next();
  const item = key.find(entry => entry?.apikey === apikey);
  if (item?.blocked) return res.status(403).json({ status: false, message: 'Esta API Key foi bloqueada pelo administrador.' });
  next();
});

// Configuração pública: nunca envia a senha administrativa ao navegador.
app.get('/api/public/config', (req, res) => {
  res.json({
    brand: 'SIXVOID APIS',
    supportWhatsapp: OWNER_WHATSAPP,
    instagram: OWNER_INSTAGRAM,
    instagramUrl: OWNER_INSTAGRAM ? `https://instagram.com/${encodeURIComponent(OWNER_INSTAGRAM)}` : ''
  });
});

app.get('/api/health', (req, res) => res.json({ status: 'online', service: 'SIXVOID APIS' }));

app.post('/api/admin/login', (req, res) => {
  if (!ADMIN_PASSWORD) return res.status(503).json({ success: false, message: 'Configure ADMIN_PASSWORD na hospedagem antes de acessar o painel.' });
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const attempt = loginAttempts.get(ip) || { count: 0, until: 0 };
  if (attempt.until > Date.now() && attempt.count >= 8) {
    return res.status(429).json({ success: false, message: 'Muitas tentativas. Aguarde alguns minutos.' });
  }
  const password = req.body && req.body.password;
  if (!sameSecret(password, ADMIN_PASSWORD)) {
    attempt.count += 1;
    if (attempt.count >= 8) attempt.until = Date.now() + 10 * 60 * 1000;
    loginAttempts.set(ip, attempt);
    return res.status(401).json({ success: false, message: 'Senha incorreta.' });
  }
  loginAttempts.delete(ip);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { expiresAt: Date.now() + SESSION_TTL });
  res.setHeader('Set-Cookie', `sixvoid_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_TTL / 1000}${req.secure ? '; Secure' : ''}`);
  res.json({ success: true, message: 'Acesso autorizado.' });
});

app.post('/api/admin/logout', (req, res) => {
  const token = parseCookies(req).sixvoid_admin;
  if (token) sessions.delete(token);
  res.setHeader('Set-Cookie', 'sixvoid_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' + (req.secure ? '; Secure' : ''));
  res.json({ success: true });
});

app.get('/api/admin/session', (req, res) => res.json({ authenticated: isAdmin(req) }));

app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const totalKeys = key.length;
  const activeKeys = key.filter(item => Number(item?.request) > 0 && !item?.blocked).length;
  const blockedKeys = key.filter(item => Boolean(item?.blocked)).length;
  const exhaustedKeys = key.filter(item => Number(item?.request) <= 0).length;
  res.json({ success: true, stats: {
    totalKeys,
    activeKeys,
    exhaustedKeys,
    blockedKeys,
    requests: Number(metrics.totalRequests) || 0,
    registeredUsers: users.length
  }});
});

app.get('/api/admin/keys', requireAdmin, (req, res) => {
  res.json({ success: true, keys: key.map(item => ({ apikey: String(item.apikey), request: Number(item.request) || 0, blocked: Boolean(item.blocked) })) });
});

app.post('/api/admin/keys', requireAdmin, (req, res) => {
  const limit = Number(req.body?.limit);
  if (!Number.isSafeInteger(limit) || limit < 1 || limit > 1000000000) {
    return res.status(400).json({ success: false, message: 'Informe um limite válido entre 1 e 1.000.000.000.' });
  }
  let apikey;
  do { apikey = `sv_${crypto.randomBytes(18).toString('hex')}`; }
  while (key.some(item => item.apikey === apikey));
  key.push({ apikey, request: limit, blocked: false });
  saveKeys();
  res.status(201).json({ success: true, key: { apikey, request: limit } });
});

app.post('/api/admin/keys/:apikey/block', requireAdmin, (req, res) => {
  const item = key.find(entry => entry.apikey === req.params.apikey);
  if (!item) return res.status(404).json({ success: false, message: 'Chave não encontrada.' });
  item.blocked = req.body?.blocked === true;
  saveKeys();
  res.json({ success: true, blocked: item.blocked });
});

app.delete('/api/admin/keys/:apikey', requireAdmin, (req, res) => {
  const index = key.findIndex(item => item.apikey === req.params.apikey);
  if (index < 0) return res.status(404).json({ success: false, message: 'Chave não encontrada.' });
  key.splice(index, 1);
  saveKeys();
  res.json({ success: true, message: 'Chave removida.' });
});

app.post('/api/admin/keys/:apikey/recharge', requireAdmin, (req, res) => {
  const amount = Number(req.body?.amount);
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 1000000000) {
    return res.status(400).json({ success: false, message: 'Informe uma recarga válida.' });
  }
  const item = key.find(entry => entry.apikey === req.params.apikey);
  if (!item) return res.status(404).json({ success: false, message: 'Chave não encontrada.' });
  item.request = Math.max(0, Number(item.request) || 0) + amount;
  saveKeys();
  res.json({ success: true, key: { apikey: item.apikey, request: item.request } });
});

// Rota principal
app.get('/', (req, res) => res.sendFile(path.join(ROOT, 'public', 'index.html')));
app.get('/admin', (req, res) => res.redirect('/admin.html'));
app.get('/solicitar-key', (req, res) => res.redirect('/solicitar-key.html'));

const gerarnick = require('./lib/gerarnick.js');
const { playstore, nerding } = require('./apis/scraper.js');
const { PlayStoreSearch } = require('./lib/scraper/pesquisas.js');
const { Estadao } = require('./lib/scraper/noticias.js');
const fetch = require('node-fetch');

async function fetchJson(url, options) {
  const response = await fetch(url, options);
  return response.json();
}
async function getBuffer(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Falha ao buscar mídia: ${response.status}`);
  return response.buffer();
}
async function Request(url) {
  const response = await fetch(url);
  return response.json();
}

async function listkeys(apikey, req) {
  const index = key.findIndex(item => item?.apikey === apikey);
  if (index < 0) return false;
  key[index].request = Math.max(0, (Number(key[index].request) || 0) - 2);
  saveKeys();
  metrics.totalRequests = (Number(metrics.totalRequests) || 0) + 1;
  metrics.lastRequestAt = new Date().toISOString();
  saveMetrics();

  const ip = String(req.headers['x-real-ip'] || req.ip || req.socket.remoteAddress || 'unknown');
  let user = users.find(item => item.key === apikey);
  if (!user) {
    user = { key: apikey, IP: [] };
    users.push(user);
  }
  if (!Array.isArray(user.IP)) user.IP = [];
  if (ip !== 'unknown' && !user.IP.includes(ip)) user.IP.push(ip);
  saveUsers();
  return true;
}


app.get('/api/keyerrada',(req, res) => {
apikey = req.query.apikey;
var ITC = key.map(i => i?.apikey)?.indexOf(apikey);
if(ITC < 0) {
return res.json({key:'Sua apikey é invalida Ou acabou as requets'})
} else {return res.json({key:`Sua ApiKey está 100% ✅ - Requests Restantes: ${key[ITC]?.request}`})}})

// Rotas antigas bloqueadas: gerenciamento agora exige sessão administrativa e POST/DELETE.
app.get('/api/add-key', (req, res) => res.status(405).json({ resultado: 'Método desativado. Use o painel administrativo autenticado.' }));
app.get('/api/del-key', (req, res) => res.status(405).json({ msg: 'Método desativado. Use o painel administrativo autenticado.' }));

app.get('/api/playstore', async(req, res, next) => {
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
nome = req.query.nome
 if (!nome) return res.json({ status : false, criador : `SANDRO BOT`, mensagem : "Coloque o parametro: nome"})
PlayStoreSearch(nome).then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
msg: `Erro no Servidor Interno`
})})})

app.get('/api/plaq',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${textoo}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq1',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://raptibef.sirv.com/images%20(1).jpeg?profile=Zanga%202.0&text.0.text=${textoo}`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq2',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://raptibef.sirv.com/images.jpeg?profile=Zanga%203.0&text.0.text=${textoo}&text.0.outline.blur=63`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq3',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://umethroo.sirv.com/peito1.jpg?text.0.text=${textoo}&text.0.position.x=-4%25&text.0.position.y=-6%25&text.0.size=14&text.0.color=000000&text.0.font.family=Shadows%20Into%20Light&text.0.font.weight=700`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq4',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://clutamac.sirv.com/1011b781-bab1-49e3-89db-ee2c064868fa%20(1).jpg?text.0.text=${textoo}&text.0.position.gravity=northwest&text.0.position.x=22%25&text.0.position.y=60%25&text.0.size=12&text.0.color=000000&text.0.opacity=47&text.0.font.family=Roboto%20Mono&text.0.font.style=italic`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq5',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://umethroo.sirv.com/Torcedora-da-sele%C3%A7%C3%A3o-brasileira-nua-mostrando-a-bunda-236x300.jpg?text.0.text=${textoo}&text.0.position.x=-64%25&text.0.position.y=-39%25&text.0.size=25&text.0.color=1b1a1a&text.0.font.family=Architects%20Daughter`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq6',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://blackzin.sirv.com/Plaq18/20220212_213215.jpg?text.0.text=${textoo}&text.0.position.gravity=northwest&text.0.position.x=43%25&text.0.position.y=18%25&text.0.size=15&text.0.color=000000&text.0.opacity=57&text.0.font.family=Vollkorn&text.0.font.weight=800&text.0.font.style=italic&text.0.background.color=000000&text.0.outline.blur=32&text.0.outline.opacity=46&text.1.text=Sandro bot%3F&text.1.position.gravity=center&text.1.position.x=10%25&text.1.position.y=30%25&text.1.size=20&text.1.color=000000&text.1.opacity=59&text.1.font.family=Playball&text.1.font.weight=700&text.1.outline.opacity=0" width="718" height="1009" alt="" />`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq7',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://ubbornag.sirv.com/Screenshot_20210513-151821.png?text.0.text=${textoo}&text.0.position.x=-40%25&text.0.position.y=-65%25&text.0.size=30&text.0.color=000000&text.0.opacity=53&text.0.font.family=Shadows%20Into%20Light20Two&text.0.outline.blur=15`)
res.type('jpg')
res.send(bala)
})

app.get('/api/plaq8',async (req,res,next) => {
var textoo = req.query.texto


bala = await getBuffer(`https://lculitas.sirv.com/ETw3FRnXgAI3Up_.jpg?text.0.text=${textoo}&text.0.position.gravity=center&text.0.align=left&text.0.size=46&text.0.color=221b1b&text.0.opacity=47&text.0.font.family=Architects%20Daughter&text.0.background.color=783852&text.0.background.opacity=5&text.0.outline.blur=58`)
res.type('jpg')
res.send(bala)
})

app.get('/api/ttp',  async (req, res) => {
texto = req.query.texto
if(!texto)return res.json({
status:false,
msg:'Cade o parametro texto??'
})
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
cor = ["f702ff","ff0202","00ff2e","efff00","00ecff","3100ff","ffb400","ff00b0","00ff95","efff00"] //CORES COLOQUE QUALQUER UMA MAS EM CODE
fonte = ["Days%20One","Domine","Exo","Fredoka%20One","Gentium%20Basic","Gloria%20Hallelujah","Great%20Vibes","Orbitron","PT%20Serif","Pacifico"]//FONTS NÃO MEXA
cores = cor[Math.floor(Math.random() * (cor.length))]	 				 
fontes = fonte[Math.floor(Math.random() * (fonte.length))]	 		
sitee = `https://huratera.sirv.com/PicsArt_08-01-10.00.42.png?profile=Example-Text&text.0.text=${texto}&text.0.outline.color=000000&text.0.outline.blur=0&text.0.outline.opacity=55&text.0.color=${cores}&text.0.font.family=${fontes}&text.0.background.color=ff0000`
res.type('jpg')
res.send(await getBuffer(sitee))
})

app.get('/nsfw/ass', async (req, res, next) => {
	apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
	   
    const ass = JSON.parse(fs.readFileSync(bla + '/data/ass.json'));
    const randass = ass[Math.floor(Math.random() * ass.length)];
    data = await fetch(randass).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/ass.jpeg', data)
    res.sendFile(bla + '/tmp/ass.jpeg')
 
})

app.get('/nsfw/cum', async (req, res, next) => {
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);		
    const cum = JSON.parse(fs.readFileSync(bla + '/data/cum.json'));
    const randcum = cum[Math.floor(Math.random() * cum.length)];
    data = await fetch(randcum).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/cum.jpeg', data)
    res.sendFile(bla + '/tmp/cum.jpeg')
})

app.get('/nsfw/gangbang', async (req, res, next) => {
      apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
    const gangbang = JSON.parse(fs.readFileSync(bla + '/data/gangbang.json'));
    const randgangbang = gangbang[Math.floor(Math.random() * gangbang.length)];
    data = await fetch(randgangbang).then(v => v.buffer())
    await fs.writeFileSync(bla + '/tmp/gangbang.jpg', data)
    res.sendFile(bla + '/tmp/gangbang.jpg')
 
})

app.get('/api/xnxxsearch', async(req, res, next) => {
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
q = req.query.q
 if (!q) return res.json({ status : false, criador : `SANDRO BOT`, mensagem : "Coloque o parametro: q"})
xnxxsearch(q).then(result => {
res.json({
status: true,
código: 200,
criador: `${criador}`,
resultado: result
})}).catch(e => {
res.json({
msg: `Erro no Servidor Interno`
})})})

app.get('/api/fazernick', async (req, res) => {
  apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
let nome = req.query.nome || res.json({msg: 'insira o parâmetro: ?nome='})
await gerarnick(nome)
.then(nicks => {
res.send(nicks) 
}).catch(e => {
res.json({erro:'Erro no Servidor Interno'})
})
})

app.get('/random/metadinha', async (req, res, next) => {
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
         json = JSON.parse(fs.readFileSync(bla +'/lib/metadinha.json').toString())
         random = json[Math.floor(Math.random() * json.length)]
         res.json(random) 
})

app.get('/api/nerding', async (req, res, next) => {
    try {
        const apikey = req.query.apikey;
        const q = req.query.q;

        if (!apikey) return res.json({ resultado: 'Cade o parametro apikey?' });
        if (!q) return res.json({ status: false, criador: 'SANDRO BOT', mensagem: "Coloque o parametro: q" });

        if (!key || !Array.isArray(key)) return res.json({ erro: 'Erro no servidor: banco de keys não carregado' });

        const keyIndex = key.findIndex(i => i?.apikey === apikey);
        if (keyIndex === -1) return res.sendFile(path.join(__dirname, "./public/", "limited.html"));

        if (key[keyIndex]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"));

        await listkeys(apikey, req);

        nerding(q)
            .then(resultado => {
                res.json({
                    status: true,
                    código: 200,
                    criador: 'SANDRO BOT',
                    resultado: resultado
                });
            })
            .catch(e => {
                console.error("Erro no nerding:", e);
                res.json({ msg: "Erro no Servidor Interno" });
            });

    } catch (error) {
        console.error("Erro interno:", error);
        res.json({ msg: "Erro no Servidor Interno" });
    }
});

app.get('/api/noticias/estadao', async(req, res, next) => {
apikey = req.query.apikey
if(key[key.map(i => i?.apikey)?.indexOf(apikey)]?.request <= 0) return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
if(!apikey)return res.json({resultado:'Cade o parametro apikey?'})
if(!key.map(i => i.apikey)?.includes(apikey))return res.sendFile(path.join(__dirname, "./public/", "limited.html"))
await listkeys(apikey, req);
Estadao().then(data => {
res.json({
pesquisa: data
})}).catch(e => {
res.json({
msg: `Erro no Servidor Interno`
})})})

// Inicia o servidor
app.listen(PORT, HOST, () => {
  console.log(`SIXVOID APIS online em http://${HOST}:${PORT}`);
  if (!ADMIN_PASSWORD) console.warn('ATENÇÃO: defina ADMIN_PASSWORD nas variáveis de ambiente para habilitar o painel.');
});